#--------Generalized Linear Modeling----------#
#---------using glm----------#
#Reference: Professor Chris Mack

#random values for y
y = c(4.35, 5.89, 3.76, 6.78, 8.81, 6.80, 7.71, 8.18, 9.91, 10.90, 9.50)

#both below does the same-give integers from 3 to 13 (11 in total)
x = 3:13
x = seq(3,13,1)

#Plotting the data
plot(y~x)

#OLS using the lm model
#Ordinary least square to determine the parameters of a 
#linear function of a set of expanatory variables
#by minimizing the sum of squares of the differences 
#between the observed dependent variable (actual values of the variables predicted)
#in the given dataset and those predicted by the linear function.
model = lm(y~x)
summary(model)


#OLS using the generalized linear modeling routine glm
model.glm = glm(y~x, family = gaussian(link = "identity"))
summary(model.glm)

#Family
#binomial, gaussian, gamma, inverse.gaussian, poisson, quasi, quasibinomial, quasipoisson
#Default link function
#logit, identity, inverse, 1/mu^2, log, (link = "identity", variance = "constant"), logit, log
#(family-->default link function)
data.small = subset(retail_data, select = c(2,3,4,5))
model.retail.glm = glm(T_Cost~., family = gaussian(link = "identity"), data = data.small)
summary(model.retail.glm)


data.smaller = subset(data.small, select = c(3,4))

model.final.glm = glm(T_Cost~., family = gaussian(link = "identity"), data = data.smaller)
summary(model.final.glm)
confint(model.final.glm)

plot(model.final.glm)

plot(data.smaller$T_Cost~data.smaller$Dress_C)


y = data.smaller$T_Cost - model.final.glm$fitted.values

data.new = data.small
data.new$Dress_A = model.final.glm$fitted.values
colnames(data.new)[1] = "Predicted_values"

data.new$Dress_B = data.new$T_Cost
colnames(data.new)[2] = "Actual_T_Cost"

data.new$Dress_C = y
colnames(data.new)[3] = "Difference_Predicted_Actual"

data.new$T_Cost = (data.new$Difference_Predicted_Actual/data.new$Actual_T_Cost)*100
colnames(data.new)[4] = "Percentage_Diff"

hits = sum(data.new$Percentage_Diff<20 & data.new$Percentage_Diff>-20)
hitsratio = hits/length(y)

#hitsratio is coming out as 90%